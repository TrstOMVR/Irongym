# IRON ECLIPSE Pro

Offline Android workout app prototype.

Included changes:
- Workout + Progress only; Nutrition and Forms are removed.
- Swipe navigation between Workout and Progress is disabled.
- RIR target is 0–1.
- Program Sheet is removed.
- Progress hero uses an original Greek-statue style SVG asset instead of a person's face.
- Exercise thumbnails use local offline SVG assets for each exercise.
- IRON ECLIPSE logo is included in the header.
- No network connection is required for the app UI/assets.

Build with the included GitHub Actions workflow or Gradle 8.7 + Android SDK 35.
