package com.iron.eclipsegym;

import android.app.*;
import android.os.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.content.*;
import android.content.res.ColorStateList;
import android.database.*;
import android.database.sqlite.*;
import android.view.*;
import android.view.animation.*;
import android.widget.*;
import java.text.*;
import java.util.*;
import android.animation.ObjectAnimator;
import android.animation.AnimatorSet;
import android.media.MediaPlayer;
import android.media.AudioAttributes;

public class MainActivity extends Activity {
    final int BG=Color.rgb(6,7,8), PANEL=Color.rgb(16,17,19), PANEL2=Color.rgb(23,25,28);
    final int LINE=Color.rgb(42,45,49), TXT=Color.rgb(245,246,248), MUTED=Color.rgb(151,156,164);
    final int RED=Color.rgb(220,42,42), RED2=Color.rgb(110,16,20), GREEN=Color.rgb(177,210,188);

    DB db; LinearLayout root, body; Handler handler=new Handler(); long timerEnd;
    MediaPlayer musicPlayer; boolean musicOn=true; Button musicButton; String currentScreen="HOME";
    final String[] days={"SUNDAY","TUESDAY","THURSDAY"};
    final String[] dayArabic={"الأحد","الثلاثاء","الخميس"};
    // Sunday and Thursday sessions swapped per user request.
    final String[][] ex={
        {"Fly","Upper Chest Press","Lat Pulldown","T-Bar Row","Biceps Curl","Triceps Extension","Lateral Raise","Deadlift","Lateral Raise (2)"},
        {"Chest Press","Lat Pulldown","Single-Arm Lat Extension","Biceps Curl","Triceps Extension","Lateral Raise","Leg Curl (Hamstrings)"},
        {"Upper Chest Press","T-Bar Row","Lat Pulldown","Biceps Curl","Triceps Extension (Pushdown)","Lateral Raise","Leg Extension (Quads)","Tibialis Raise"}
    };
    final int[][] sets={{2,2,1,2,1,1,2,1,2},{2,2,1,2,2,2,2},{2,2,1,2,2,2,2,2}};
    final String[][] reps={{"6–8","6–8","6–8","6–8","6–8","6–8","6–8","6","6–8"},{"6–8","6–8","6–8","6–8","6–8","6–8","6–8"},{"6–8","6–8","6–8","6–8","6–8","6–8","6–8","8–12"}};

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        db=new DB(this);
        musicOn=getSharedPreferences("iron_eclipse",MODE_PRIVATE).getBoolean("music_on",true);
        showIntro();
    }

    TextView t(String s,float z,int c){
        TextView v=new TextView(this); v.setText(s); v.setTextSize(z); v.setTextColor(c);
        v.setGravity(Gravity.CENTER_VERTICAL); v.setPadding(14,7,14,7); return v;
    }
    TextView bold(String s,float z){ TextView v=t(s,z,TXT); v.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return v; }

    GradientDrawable bg(int color,int stroke){
        GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(22);
        if(stroke>0) g.setStroke(1,LINE); return g;
    }
    GradientDrawable redBg(){
        GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,
            new int[]{RED,Color.rgb(150,22,28)}); g.setCornerRadius(22); return g;
    }
    Button button(String s){
        Button b=new Button(this); b.setText(s); b.setTextColor(TXT); b.setTextSize(11);
        b.setAllCaps(false); b.setMinHeight(0); b.setMinWidth(0); b.setPadding(10,0,10,0);
        b.setBackground(bg(PANEL2,1)); b.setStateListAnimator(null); return b;
    }
    EditText field(String h){
        EditText e=new EditText(this); e.setHint(h); e.setHintTextColor(MUTED); e.setTextColor(TXT);
        e.setTextSize(12); e.setSingleLine(); e.setInputType(2|8192); e.setPadding(10,0,10,0);
        e.setBackground(bg(PANEL2,1)); return e;
    }

    void animateIn(View v,int delay){
        v.setAlpha(0f); v.setTranslationY(18f);
        v.animate().alpha(1f).translationY(0f).setDuration(360).setStartDelay(delay)
            .setInterpolator(new DecelerateInterpolator()).start();
    }
    void pressAnim(View v){
        v.setOnTouchListener((view,event)->{
            if(event.getAction()==MotionEvent.ACTION_DOWN)
                view.animate().scaleX(.985f).scaleY(.985f).setDuration(70).start();
            else if(event.getAction()==MotionEvent.ACTION_UP || event.getAction()==MotionEvent.ACTION_CANCEL)
                view.animate().scaleX(1f).scaleY(1f).setDuration(90).start();
            return false;
        });
    }

    void shell(String title){
        currentScreen = title.toUpperCase(Locale.US);
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG);
        LinearLayout head=new LinearLayout(this); head.setOrientation(LinearLayout.VERTICAL); head.setPadding(16,16,16,7);

        LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
        TextView mark=bold("IRON",20); mark.setTextColor(RED); row.addView(mark);
        TextView mark2=bold(" ECLIPSE",20); row.addView(mark2);
        Space sp=new Space(this); row.addView(sp,new LinearLayout.LayoutParams(0,1,1));
        musicButton=button(musicOn?"MUSIC ON":"MUSIC OFF");
        musicButton.setTextSize(9); musicButton.setPadding(7,0,7,0);
        musicButton.setOnClickListener(v->toggleMusic());
        row.addView(musicButton,new LinearLayout.LayoutParams(88,42));
        head.addView(row);
        TextView sub=t(title+"  /  FORGED IN SILENCE",11,MUTED); sub.setPadding(2,1,2,2); head.addView(sub);
        root.addView(head);

        ScrollView sv=new ScrollView(this); sv.setClipToPadding(false);
        body=new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL); body.setPadding(14,8,14,110);
        sv.addView(body); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1)); nav();
        setContentView(root);
    }

    void nav(){
        LinearLayout n=new LinearLayout(this); n.setPadding(8,7,8,7); n.setBackgroundColor(PANEL);
        String[] a={"HOME","WORKOUT","PROGRESS"};
        for(String s:a){
            Button b=button(s); b.setTextSize(10); if((s.equals("HOME")&&currentScreen.contains("DASHBOARD"))||(s.equals("WORKOUT")&&currentScreen.contains("FULL BODY"))||(s.equals("PROGRESS")&&currentScreen.equals("PROGRESS"))) b.setBackground(redBg()); n.addView(b,new LinearLayout.LayoutParams(0,55,1));
            if(s.equals("HOME")) b.setOnClickListener(v->home());
            if(s.equals("WORKOUT")) b.setOnClickListener(v->workout(nextDay()));
            if(s.equals("PROGRESS")) b.setOnClickListener(v->progress());
        }
        root.addView(n,new LinearLayout.LayoutParams(-1,70));
    }
    void gap(){ Space x=new Space(this); body.addView(x,new LinearLayout.LayoutParams(1,9)); }

    LinearLayout baseCard(){
        LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(13,12,13,12);
        c.setBackground(bg(PANEL,1)); c.setElevation(3f); pressAnim(c); return c;
    }
    void card(String title,String sub,View.OnClickListener l){
        LinearLayout c=baseCard(); c.addView(bold(title,16));
        if(sub!=null){ TextView x=t(sub,12,MUTED); c.addView(x); }
        if(l!=null) c.setOnClickListener(l); body.addView(c); animateIn(c,60+body.getChildCount()*20); gap();
    }
    void addStat(LinearLayout stats,String label,String value){
        LinearLayout c=baseCard(); c.setGravity(Gravity.CENTER); c.setPadding(6,10,6,10);
        c.addView(bold(value,20)); TextView lab=t(label,9,MUTED); lab.setGravity(Gravity.CENTER); c.addView(lab);
        stats.addView(c,new LinearLayout.LayoutParams(0,82,1)); animateIn(c,100+stats.getChildCount()*40);
    }
    void hero(String title,String sub){
        LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(17,18,17,18);
        c.setBackground(redBg()); c.setElevation(6f);
        TextView a=bold(title,25); a.setTextColor(Color.WHITE); c.addView(a);
        TextView b=t(sub,11,Color.WHITE); b.setAlpha(.88f); c.addView(b);
        body.addView(c); animateIn(c,20); gap();
    }

    void home(){
        shell("DASHBOARD");
        hero("IRON ECLIPSE COMMAND","3 DAY FULL BODY  •  TRAIN HARD, LOG SMART, RECOVER WELL");

        LinearLayout stats=new LinearLayout(this); stats.setWeightSum(2);
        addStat(stats,"LOGGED SETS",String.valueOf(db.count()));
        addStat(stats,"WORKOUT DAYS",String.valueOf(db.workoutDays()));
        body.addView(stats); gap();
        LinearLayout stats2=new LinearLayout(this); stats2.setWeightSum(2);
        addStat(stats2,"TOTAL VOLUME",formatKg(db.totalVolume()));
        addStat(stats2,"TOTAL SETS",String.valueOf(db.count()));
        body.addView(stats2); gap();

        card("TODAY'S SNAPSHOT",db.todaySets()+" sets  •  "+formatKg(db.todayVolume())+" volume",v->progress());
        int d=nextDay();
        card("NEXT SESSION",dayArabic[d]+"  •  FULL BODY "+(char)('A'+d),v->workout(d));
        card("WORKOUT CALENDAR",db.workoutDays()+" training days logged  •  open monthly calendar",v->calendarScreen());
        card("ACHIEVEMENTS",db.achievementSummary(),v->achievements());
        card("REST TIMER","3:00 default  •  +30 SEC / SKIP available",v->timer(180));
    }

    String formatKg(double v){
        if(v>=1000) return String.format(Locale.US,"%.1f t",v/1000.0);
        return String.format(Locale.US,"%.0f kg",v);
    }

    int uniqueExercises(){HashSet<String>s=new HashSet<>(); for(String[] a:ex)for(String x:a)s.add(x.replace(" (2)","")); return s.size();}
    int nextDay(){
        Calendar c=Calendar.getInstance(); int d=c.get(Calendar.DAY_OF_WEEK);
        if(d==Calendar.SUNDAY)return 0;
        if(d==Calendar.MONDAY)return 1;
        if(d==Calendar.TUESDAY)return 1;
        if(d==Calendar.WEDNESDAY)return 2;
        if(d==Calendar.THURSDAY)return 2;
        return 0; // Friday/Saturday → next session is Sunday
    }

    void workout(int di){
        shell(dayArabic[di]+"  •  FULL BODY "+(char)('A'+di));
        LinearLayout tabs=new LinearLayout(this); tabs.setWeightSum(3);
        for(int i=0;i<3;i++){ final int q=i; Button b=button(dayArabic[i]); if(i==di)b.setBackground(redBg());
            tabs.addView(b,new LinearLayout.LayoutParams(0,52,1)); b.setOnClickListener(v->workout(q)); }
        body.addView(tabs); gap();
        hero("SESSION READY",""+ex[di].length+" EXERCISES   •   "+setsCount(di)+" WORKING SETS   •   REST 3:00");
        for(int i=0;i<ex[di].length;i++) exercise(di,i);
    }
    int setsCount(int di){int n=0;for(int x:sets[di])n+=x;return n;}

    void exercise(int di,int ei){
        String name=ex[di][ei].replace(" (2)","");
        LinearLayout c=baseCard(); c.setPadding(10,10,10,10);
        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        ImageView im=exerciseImage(name); top.addView(im,new LinearLayout.LayoutParams(96,78));
        LinearLayout info=new LinearLayout(this); info.setOrientation(LinearLayout.VERTICAL); info.setPadding(10,0,6,0);
        info.addView(bold(name,16)); info.addView(t(muscleFor(name).toUpperCase(Locale.US),9,MUTED));
        info.addView(t(sets[di][ei]+" × "+reps[di][ei]+"   •   FAILURE",11,RED));
        top.addView(info,new LinearLayout.LayoutParams(0,-2,1));
        Button details=button("DETAILS"); top.addView(details,new LinearLayout.LayoutParams(76,48));
        c.addView(top);

        String last=db.lastFor(name);
        if(!last.equals("—")){TextView lp=t("LAST  "+last,10,MUTED); lp.setPadding(106,2,5,5); c.addView(lp);}

        for(int si=1;si<=sets[di][ei];si++){
            LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
            TextView sn=t("SET "+si,10,MUTED); sn.setGravity(Gravity.CENTER); row.addView(sn,new LinearLayout.LayoutParams(52,48));
            EditText w=field("kg"),r=field("reps");
            row.addView(w,new LinearLayout.LayoutParams(0,48,1)); row.addView(r,new LinearLayout.LayoutParams(0,48,1));
            TextView fail=t("FAILURE",10,RED); fail.setGravity(Gravity.CENTER); row.addView(fail,new LinearLayout.LayoutParams(0,48,1));
            Button save=button("SAVE"); row.addView(save,new LinearLayout.LayoutParams(60,48));
            final String logName=name; final Button saveBtn=save;
            save.setOnClickListener(v->{try{
                double kg=Double.parseDouble(w.getText().toString()); int rr=Integer.parseInt(r.getText().toString());
                int ri=0;
                if(kg<=0||rr<=0||rr>100) throw new Exception();
                db.log(logName,kg,rr,ri); saveBtn.setText("SAVED"); saveBtn.setTextColor(GREEN);
                Toast.makeText(this,"Set saved",Toast.LENGTH_SHORT).show();
            }catch(Exception z){Toast.makeText(this,"Enter a valid weight and reps",Toast.LENGTH_SHORT).show();}});
            c.addView(row); gapSmall(c);
        }
        Button rest=button("START 3:00 REST"); rest.setBackground(redBg()); rest.setOnClickListener(v->timer(180)); c.addView(rest);
        details.setOnClickListener(v->exerciseDetails(name,di,ei)); c.setOnClickListener(v->{}); body.addView(c);
        animateIn(c,70+body.getChildCount()*18); gap();
    }
    void gapSmall(LinearLayout l){Space s=new Space(this);l.addView(s,new LinearLayout.LayoutParams(1,4));}

    ImageView exerciseImage(String name){
        ImageView im=new ImageView(this); int id=imgId(name); if(id!=0)im.setImageResource(id);
        im.setScaleType(ImageView.ScaleType.CENTER_CROP); im.setBackground(bg(PANEL2,1)); im.setClipToOutline(true);
        return im;
    }
    int imgId(String n){
        if(n.equals("Upper Chest Press"))return R.drawable.upper_chest_press;
        if(n.equals("T-Bar Row"))return R.drawable.tbar_row;
        if(n.equals("Lat Pulldown"))return R.drawable.lat_pulldown;
        if(n.equals("Biceps Curl"))return R.drawable.biceps_curl;
        if(n.contains("Triceps Extension"))return R.drawable.triceps_extension;
        if(n.equals("Lateral Raise"))return R.drawable.lateral_raise;
        if(n.equals("Leg Extension (Quads)"))return R.drawable.leg_extension;
        if(n.equals("Tibialis Raise"))return R.drawable.tibialis_raise;
        if(n.equals("Chest Press"))return R.drawable.chest_press;
        if(n.equals("Single-Arm Lat Extension"))return R.drawable.single_arm_lat_extension;
        if(n.equals("Leg Curl (Hamstrings)"))return R.drawable.leg_curl;
        if(n.equals("Fly"))return R.drawable.fly;
        if(n.equals("Deadlift"))return R.drawable.deadlift;
        return 0;
    }
    String muscleFor(String n){
        if(n.contains("Chest")||n.equals("Fly"))return "Chest";
        if(n.contains("Row")||n.contains("Pulldown")||n.contains("Lat"))return "Back / Lats";
        if(n.contains("Biceps"))return "Biceps";
        if(n.contains("Triceps"))return "Triceps";
        if(n.contains("Lateral Raise"))return "Lateral Delts";
        if(n.contains("Leg Extension"))return "Quads";
        if(n.contains("Leg Curl"))return "Hamstrings";
        if(n.contains("Tibialis"))return "Tibialis";
        if(n.equals("Deadlift"))return "Hamstrings / Glutes / Back";
        return "—";
    }
    String guideFor(String n){
        if(n.contains("Chest Press"))return "Keep shoulder blades stable, control the descent, and press smoothly without bouncing.";
        if(n.equals("Fly"))return "Use a controlled stretch and bring the handles together without turning the movement into a press.";
        if(n.equals("T-Bar Row"))return "Brace your torso, pull toward the lower chest or upper abdomen, then control the lowering phase.";
        if(n.equals("Lat Pulldown"))return "Pull toward the upper chest with the elbows driving down; avoid excessive swinging.";
        if(n.contains("Lat Extension"))return "Keep the upper arm stable and move through a controlled range.";
        if(n.contains("Biceps"))return "Keep the upper arm relatively still, curl through the elbow, and control the lowering phase.";
        if(n.contains("Triceps"))return "Keep the elbows stable and extend under control.";
        if(n.equals("Lateral Raise"))return "Raise with controlled motion and avoid using momentum.";
        if(n.contains("Leg Extension"))return "Align the knee with the machine pivot and extend smoothly without bouncing.";
        if(n.contains("Leg Curl"))return "Keep the hips stable and curl the pad through a controlled range.";
        if(n.contains("Tibialis"))return "Lift the forefoot through a controlled range while keeping the heel planted.";
        if(n.equals("Deadlift"))return "Brace first, keep the load close, hinge at the hips, and stop if technique breaks down.";
        return "Use controlled reps and stable technique. Stop the set when safe technique can no longer be maintained.";
    }

    void exerciseDetails(String name,int di,int ei){
        final Dialog d=new Dialog(this);
        LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(18,18,18,18); l.setBackground(bg(PANEL,1));
        LinearLayout head=new LinearLayout(this); head.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(bold(name,21),new LinearLayout.LayoutParams(0,-2,1));
        Button x=button("×"); head.addView(x,new LinearLayout.LayoutParams(48,48)); l.addView(head);
        ImageView im=exerciseImage(name); l.addView(im,new LinearLayout.LayoutParams(-1,235));
        l.addView(t("TARGET  •  "+muscleFor(name),12,RED));
        l.addView(t("PROGRAM  •  "+sets[di][ei]+" SETS × "+reps[di][ei]+"  •  FAILURE",12,TXT));
        l.addView(t("FORM GUIDE\n"+guideFor(name),12,MUTED));
        l.addView(t("LAST PERFORMANCE\n"+db.lastFor(name),12,MUTED));
        Button history=button("VIEW EXERCISE PROGRESS"); l.addView(history);
        Button close=button("CLOSE"); l.addView(close);
        x.setOnClickListener(v->d.dismiss()); close.setOnClickListener(v->d.dismiss());
        history.setOnClickListener(v->{d.dismiss();exerciseProgress(name);});
        d.setContentView(l); d.show();
        Window w=d.getWindow(); if(w!=null){w.setBackgroundDrawable(bg(PANEL,1)); w.setLayout(-1,-2);}
        animateIn(l,0);
    }

    void exerciseProgress(String name){
        shell(name+"  •  PROGRESS");
        card("RECENT SETS",db.exerciseHistory(name),null);
        body.addView(bold("VOLUME TREND",17)); gap();
        body.addView(new ChartView(this,db.exerciseChart(name)),new LinearLayout.LayoutParams(-1,260));
    }

    void timer(int sec){
        final Dialog d=new Dialog(this); LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(25,25,25,25); l.setBackground(bg(PANEL,1));
        TextView title=bold("REST TIMER",19); title.setGravity(Gravity.CENTER); l.addView(title);
        TextView clock=bold(String.format(Locale.US,"%d:%02d",sec/60,sec%60),52); clock.setGravity(Gravity.CENTER); l.addView(clock,new LinearLayout.LayoutParams(-1,120));
        LinearLayout controls=new LinearLayout(this); controls.setWeightSum(3);
        Button plus=button("+30 SEC"), skip=button("SKIP"), stop=button("STOP");
        controls.addView(plus,new LinearLayout.LayoutParams(0,52,1)); controls.addView(skip,new LinearLayout.LayoutParams(0,52,1)); controls.addView(stop,new LinearLayout.LayoutParams(0,52,1)); l.addView(controls);
        d.setContentView(l); d.show(); Window win=d.getWindow(); if(win!=null){win.setBackgroundDrawable(bg(PANEL,1));win.setLayout(-1,-2);}
        final long[] end={System.currentTimeMillis()+sec*1000L};
        Runnable rr=new Runnable(){public void run(){long left=Math.max(0,end[0]-System.currentTimeMillis());
            clock.setText(String.format(Locale.US,"%d:%02d",left/60000,(left/1000)%60));
            if(left>0)handler.postDelayed(this,200); else {clock.setText("DONE");clock.setTextColor(RED); try{((android.os.Vibrator)getSystemService(VIBRATOR_SERVICE)).vibrate(250);}catch(Exception ignored){}}
        }};
        plus.setOnClickListener(v->end[0]+=30000L);
        skip.setOnClickListener(v->{handler.removeCallbacks(rr);clock.setText("SKIPPED");clock.setTextColor(MUTED);});
        stop.setOnClickListener(v->{handler.removeCallbacks(rr);d.dismiss();});
        d.setOnDismissListener(x->handler.removeCallbacks(rr)); handler.post(rr);
    }

    void progress(){
        shell("PROGRESS");
        hero("PROGRESS LAB","Exercise trends, volume analytics and training history.");
        LinearLayout stats=new LinearLayout(this); stats.setWeightSum(3);
        addStat(stats,"SETS",String.valueOf(db.count())); addStat(stats,"DAYS",String.valueOf(db.workoutDays())); addStat(stats,"VOLUME",formatKg(db.totalVolume()));
        body.addView(stats); gap();
        if(db.count()==0){body.addView(t("No sets logged yet. Start your first session to build your graph.",14,MUTED)); return;}
        body.addView(bold("OVERALL VOLUME TREND",17)); gap();
        body.addView(new ChartView(this,db.chart()),new LinearLayout.LayoutParams(-1,260)); gap();
        card("WORKOUT ANALYTICS",db.thisWeekVolumeLabel(),v->analytics());
        body.addView(bold("EXERCISE GRAPH",17)); gap();
        Spinner pick=new Spinner(this); ArrayList<String> names=db.exerciseNames();
        ArrayAdapter<String> ad=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,names); ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); pick.setAdapter(ad); body.addView(pick); gap();

        FrameLayout chartBox=new FrameLayout(this); chartBox.setBackground(bg(PANEL,1)); body.addView(chartBox,new LinearLayout.LayoutParams(-1,280));
        Runnable render=()->{chartBox.removeAllViews(); String n=(String)pick.getSelectedItem(); if(n!=null){chartBox.addView(new ChartView(this,db.exerciseChart(n)),new FrameLayout.LayoutParams(-1,-1));}};
        pick.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){} public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){render.run();}}); render.run(); gap();
        card("RECENT HISTORY",db.recent(),null);
    }

    void analytics(){
        shell("WORKOUT ANALYTICS");
        hero("TRAINING ANALYTICS","See your volume, sets and recent performance in one place.");
        LinearLayout stats=new LinearLayout(this); stats.setWeightSum(2); addStat(stats,"THIS WEEK SETS",String.valueOf(db.weekSets())); addStat(stats,"THIS WEEK VOLUME",formatKg(db.weekVolume())); body.addView(stats); gap();
        card("THIS WEEK",db.thisWeekVolumeLabel(),null);
        card("LAST WEEK",db.lastWeekVolumeLabel(),null);
        body.addView(bold("RECENT VOLUME",17)); gap();
        body.addView(new ChartView(this,db.weeklyVolumeChart()),new LinearLayout.LayoutParams(-1,260)); gap();
        card("ACHIEVEMENTS",db.achievementSummary(),v->achievements());
    }

    void calendarScreen(){
        shell("WORKOUT CALENDAR");
        hero("TRAINING CALENDAR","Logged sessions are marked automatically. Consistency is built one session at a time.");
        Calendar now=Calendar.getInstance(); int year=now.get(Calendar.YEAR), month=now.get(Calendar.MONTH);
        body.addView(bold(new SimpleDateFormat("MMMM yyyy",Locale.US).format(now.getTime()).toUpperCase(Locale.US),20)); gap();
        GridLayout grid=new GridLayout(this); grid.setColumnCount(7); grid.setPadding(4,4,4,4);
        String[] heads={"S","M","T","W","T","F","S"}; for(String h:heads){TextView v=t(h,11,MUTED);v.setGravity(Gravity.CENTER);grid.addView(v,new GridLayout.LayoutParams());}
        Calendar first=new GregorianCalendar(year,month,1); int offset=first.get(Calendar.DAY_OF_WEEK)-1; int daysIn=first.getActualMaximum(Calendar.DAY_OF_MONTH);
        for(int i=0;i<offset;i++) grid.addView(t("",12,MUTED),cellParams());
        for(int day=1;day<=daysIn;day++){TextView v=t(String.valueOf(day),11,TXT);v.setGravity(Gravity.CENTER); if(db.hasWorkoutDate(year,month,day))v.setTextColor(RED); grid.addView(v,cellParams());}
        body.addView(grid); gap();
        card("STREAK",db.streak()+" consecutive logged training day(s)",null);
        card("MONTH",db.monthDays(year,month)+" training day(s) this month",null);
    }
    GridLayout.LayoutParams cellParams(){GridLayout.LayoutParams p=new GridLayout.LayoutParams();p.width=0;p.height=52;p.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);p.setMargins(2,2,2,2);return p;}

    void achievements(){
        shell("ACHIEVEMENTS"); hero("IRON ECLIPSE ACHIEVEMENTS","Milestones earned from the training data you actually log.");
        String[][] a={{"FIRST SET","Log your first working set.",db.count()>=1?"UNLOCKED":"LOCKED"},{"TEN WORKOUTS","Reach 10 logged training days.",db.workoutDays()>=10?"UNLOCKED":"LOCKED"},{"FIFTY SETS","Log 50 working sets.",db.count()>=50?"UNLOCKED":"LOCKED"},{"SEVEN DAY STREAK","Train on 7 consecutive logged days.",db.streak()>=7?"UNLOCKED":"LOCKED"}};
        for(String[] x:a) card(x[0],x[2]+"  •  "+x[1],null);
    }


    void checklist(){
        final Dialog d=new Dialog(this);
        LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(20,20,20,20); l.setBackground(bg(PANEL,1));
        l.addView(bold("SESSION CHECKLIST",21));
        l.addView(t("01  •  WARM UP",13,RED));
        l.addView(t("Do a few easy ramp-up sets before the first heavy working set.",12,MUTED));
        l.addView(t("02  •  SETUP",13,RED));
        l.addView(t("Adjust the machine or rack, brace properly, and keep the same setup between sets.",12,MUTED));
        l.addView(t("03  •  FAILURE",13,RED));
        l.addView(t("Train the programmed working sets hard, but end the set if safe technique breaks down.",12,MUTED));
        l.addView(t("04  •  REST",13,RED));
        l.addView(t("Take the full 3:00 timer between working sets unless your plan says otherwise.",12,MUTED));
        l.addView(t("05  •  LOG",13,RED));
        l.addView(t("Save the weight and reps immediately so your progress history stays accurate.",12,MUTED));
        Button close=button("CLOSE"); l.addView(close); close.setOnClickListener(v->d.dismiss());
        d.setContentView(l); d.show(); Window w=d.getWindow(); if(w!=null){w.setBackgroundDrawable(bg(PANEL,1));w.setLayout(-1,-2);} animateIn(l,0);
    }

    void startMusic(){
        if(!musicOn) return;
        try{
            if(musicPlayer==null){
                musicPlayer=MediaPlayer.create(this,R.raw.berserk_mix);
                if(musicPlayer!=null){
                    if(Build.VERSION.SDK_INT>=21){
                        musicPlayer.setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build());
                    }
                    musicPlayer.setVolume(1.0f,1.0f);
                    musicPlayer.setLooping(true);
                }
            }
            if(musicPlayer!=null && !musicPlayer.isPlaying()) musicPlayer.start();
        }catch(Exception ignored){}
    }

    void toggleMusic(){
        musicOn=!musicOn;
        getSharedPreferences("iron_eclipse",MODE_PRIVATE).edit().putBoolean("music_on",musicOn).apply();
        if(musicButton!=null) musicButton.setText(musicOn?"MUSIC ON":"MUSIC OFF");
        if(musicOn) startMusic();
        else if(musicPlayer!=null){try{musicPlayer.pause();}catch(Exception ignored){}}
    }

    void showIntro(){
        // Simple intro: no profile setup, no age/gender/height/weight/nutrition questions.
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_STABLE);

        FrameLayout splash=new FrameLayout(this);
        ImageView background=new ImageView(this);
        background.setImageResource(com.iron.eclipsegym.R.drawable.berserk_intro);
        background.setScaleType(ImageView.ScaleType.CENTER_CROP);
        background.setAlpha(.92f);
        splash.addView(background,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout intro=new LinearLayout(this); intro.setOrientation(LinearLayout.VERTICAL);
        intro.setGravity(Gravity.CENTER); intro.setPadding(28,28,28,28);
        TextView title=bold("IRON ECLIPSE",40); title.setGravity(Gravity.CENTER);
        title.setTextColor(Color.WHITE); intro.addView(title);
        TextView line=t("STRUGGLE  •  DISCIPLINE  •  PROGRESS",11,Color.LTGRAY);
        line.setGravity(Gravity.CENTER); intro.addView(line);
        View divider=new View(this); divider.setBackgroundColor(RED);
        LinearLayout.LayoutParams dp=new LinearLayout.LayoutParams(120,2); dp.gravity=Gravity.CENTER;
        dp.topMargin=12; dp.bottomMargin=4; intro.addView(divider,dp);
        TextView tap=t("TAP TO ENTER",10,Color.WHITE); tap.setGravity(Gravity.CENTER);
        tap.setPadding(0,24,0,0); intro.addView(tap);
        splash.addView(intro,new FrameLayout.LayoutParams(-1,-1));
        setContentView(splash);
        intro.setAlpha(0f); intro.setScaleX(.94f); intro.setScaleY(.94f);
        intro.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(900)
            .setInterpolator(new DecelerateInterpolator()).start();
        startMusic();
        Runnable enter=()->showMainFromIntro();
        tap.setOnClickListener(v->enter.run());
        splash.setOnClickListener(v->enter.run());
        // Do not auto-enter: the user must explicitly tap to continue.
    }

    void showMainFromIntro(){
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        home();
    }

    @Override protected void onPause(){
        if(musicPlayer!=null && musicPlayer.isPlaying()){try{musicPlayer.pause();}catch(Exception ignored){}}
        super.onPause();
    }

    @Override protected void onResume(){
        super.onResume();
        if(!isFinishing()) startMusic();
    }

    @Override protected void onDestroy(){
        handler.removeCallbacksAndMessages(null);
        if(musicPlayer!=null){try{musicPlayer.release();}catch(Exception ignored){}}
        super.onDestroy();
    }

    static class EclipseView extends View{
        Paint p=new Paint(1); EclipseView(Context c){super(c);p.setAntiAlias(true);}
        protected void onDraw(Canvas c){
            super.onDraw(c); float cx=getWidth()/2f, cy=getHeight()/2f;
            p.setColor(Color.rgb(45,8,10)); c.drawCircle(cx,cy,105,p);
            p.setColor(Color.rgb(220,42,42)); c.drawCircle(cx,cy,76,p);
            p.setColor(Color.rgb(6,7,8)); c.drawCircle(cx,cy,48,p);
            p.setColor(Color.rgb(15,15,16));
            Path path=new Path(); path.moveTo(cx-95,cy+100); path.lineTo(cx-60,cy+20); path.lineTo(cx-28,cy+5); path.lineTo(cx-14,cy-35); path.lineTo(cx+5,cy-55); path.lineTo(cx+25,cy-30); path.lineTo(cx+40,cy+10); path.lineTo(cx+72,cy+45); path.lineTo(cx+105,cy+100); path.close(); c.drawPath(path,p);
            p.setColor(Color.rgb(220,42,42)); p.setStrokeWidth(3); c.drawLine(cx+25,cy-100,cx+105,cy-20,p);
        }
    }

    static class ChartView extends View{
        Paint p=new Paint(1);float[] vals; ChartView(Context c,float[]v){super(c);vals=v;p.setStrokeWidth(5);}
        protected void onDraw(Canvas c){super.onDraw(c);c.drawColor(Color.rgb(16,17,19)); if(vals.length<2){p.setColor(Color.GRAY);p.setTextSize(14);c.drawText("Log more sets to see your trend.",16,30,p);return;}
            float max=1;for(float v:vals)max=Math.max(max,v);float dx=getWidth()*1f/(vals.length-1);
            p.setColor(Color.rgb(220,42,42));p.setStrokeWidth(5);
            for(int i=1;i<vals.length;i++){float x1=(i-1)*dx,x2=i*dx,y1=getHeight()-30-(vals[i-1]/max)*(getHeight()-60),y2=getHeight()-30-(vals[i]/max)*(getHeight()-60);c.drawLine(x1,y1,x2,y2,p);}
            p.setTextSize(22);p.setColor(Color.LTGRAY);c.drawText("VOLUME",16,28,p);
        }
    }

    static class DB extends SQLiteOpenHelper{
        DB(Context c){super(c,"iron_eclipse_pro.db",null,7);}
        public void onCreate(SQLiteDatabase d){
            d.execSQL("CREATE TABLE logs(id INTEGER PRIMARY KEY AUTOINCREMENT,exercise TEXT,weight REAL,reps INTEGER,rir INTEGER,date TEXT)");
        }
        public void onUpgrade(SQLiteDatabase d,int a,int b){
        }
        void log(String e,double w,int r,int rir){getWritableDatabase().execSQL("INSERT INTO logs(exercise,weight,reps,rir,date) VALUES(?,?,?,?,?)",new Object[]{e,w,r,rir,new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(new Date())});}
        Cursor raw(String q){return getReadableDatabase().rawQuery(q,null);}
        int count(){Cursor c=raw("SELECT COUNT(*) FROM logs");c.moveToFirst();int n=c.getInt(0);c.close();return n;}
        int workoutDays(){Cursor c=raw("SELECT COUNT(DISTINCT substr(date,1,10)) FROM logs");c.moveToFirst();int n=c.getInt(0);c.close();return n;}
        double totalVolume(){Cursor c=raw("SELECT COALESCE(SUM(weight*reps),0) FROM logs");c.moveToFirst();double n=c.getDouble(0);c.close();return n;}
        int todaySets(){String d=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM logs WHERE date LIKE ?",new String[]{d+"%"});c.moveToFirst();int n=c.getInt(0);c.close();return n;}
        double todayVolume(){String d=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(weight*reps),0) FROM logs WHERE date LIKE ?",new String[]{d+"%"});c.moveToFirst();double n=c.getDouble(0);c.close();return n;}
        ArrayList<String> exerciseNames(){ArrayList<String>a=new ArrayList<>();Cursor c=raw("SELECT DISTINCT exercise FROM logs ORDER BY exercise");while(c.moveToNext())a.add(c.getString(0));c.close();return a;}
        String last(){Cursor c=raw("SELECT exercise,weight,reps FROM logs ORDER BY id DESC LIMIT 1");if(c.moveToFirst()){String s=c.getString(0)+"  •  "+c.getDouble(1)+" kg × "+c.getInt(2);c.close();return s;}c.close();return "No sets logged yet.";}
        String lastFor(String e){Cursor c=getReadableDatabase().rawQuery("SELECT weight,reps FROM logs WHERE exercise=? ORDER BY id DESC LIMIT 1",new String[]{e});if(c.moveToFirst()){String s=c.getDouble(0)+" kg × "+c.getInt(1)+" • FAILURE";c.close();return s;}c.close();return "—";}
        String recent(){Cursor c=raw("SELECT exercise,weight,reps,date FROM logs ORDER BY id DESC LIMIT 12");StringBuilder s=new StringBuilder();while(c.moveToNext())s.append(c.getString(0)).append("  |  ").append(c.getDouble(1)).append(" kg × ").append(c.getInt(2)).append("  | FAILURE\n");c.close();return s.toString();}
        String exerciseHistory(String e){Cursor c=getReadableDatabase().rawQuery("SELECT weight,reps,date FROM logs WHERE exercise=? ORDER BY id DESC LIMIT 15",new String[]{e});StringBuilder s=new StringBuilder();while(c.moveToNext())s.append(c.getDouble(0)).append(" kg × ").append(c.getInt(1)).append("  • FAILURE  • ").append(c.getString(2)).append("\n");c.close();return s.length()==0?"No logged sets yet.":s.toString();}
        float[] exerciseChart(String e){Cursor c=getReadableDatabase().rawQuery("SELECT weight*reps FROM logs WHERE exercise=? ORDER BY id ASC",new String[]{e});ArrayList<Float>a=new ArrayList<>();while(c.moveToNext())a.add((float)c.getDouble(0));c.close();float[]v=new float[a.size()];for(int i=0;i<v.length;i++)v[i]=a.get(i);return v;}
        float[] chart(){Cursor c=raw("SELECT weight*reps FROM logs ORDER BY id ASC LIMIT 30");ArrayList<Float>a=new ArrayList<>();while(c.moveToNext())a.add((float)c.getDouble(0));c.close();float[]v=new float[a.size()];for(int i=0;i<v.length;i++)v[i]=a.get(i);return v;}
        int weekSets(){return rangeCount(0,6);}
        double weekVolume(){return rangeVolume(0,6);}
        double lastWeekVolume(){return rangeVolume(7,13);}
        int rangeCount(int fromDays,int toDays){Calendar c=Calendar.getInstance();c.add(Calendar.DAY_OF_YEAR,-toDays);String lo=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(c.getTime());c=Calendar.getInstance();c.add(Calendar.DAY_OF_YEAR,-fromDays);String hi=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(c.getTime());Cursor x=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM logs WHERE substr(date,1,10) BETWEEN ? AND ?",new String[]{lo,hi});x.moveToFirst();int n=x.getInt(0);x.close();return n;}
        double rangeVolume(int fromDays,int toDays){Calendar c=Calendar.getInstance();c.add(Calendar.DAY_OF_YEAR,-toDays);String lo=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(c.getTime());c=Calendar.getInstance();c.add(Calendar.DAY_OF_YEAR,-fromDays);String hi=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(c.getTime());Cursor x=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(weight*reps),0) FROM logs WHERE substr(date,1,10) BETWEEN ? AND ?",new String[]{lo,hi});x.moveToFirst();double n=x.getDouble(0);x.close();return n;}
        String thisWeekVolumeLabel(){return "This week: "+weekSets()+" sets  •  "+formatStatic(weekVolume())+" volume  •  Last week: "+formatStatic(lastWeekVolume());}
        String lastWeekVolumeLabel(){return "Last 7-day block: "+formatStatic(lastWeekVolume());}
        String achievementSummary(){return "Unlocked: "+((count()>=1?1:0)+(workoutDays()>=10?1:0)+(count()>=50?1:0)+(streak()>=7?1:0))+" / 4";}
        boolean hasWorkoutDate(int y,int m,int day){String target=String.format(Locale.US,"%04d-%02d-%02d",y,m+1,day);Cursor c=getReadableDatabase().rawQuery("SELECT 1 FROM logs WHERE date LIKE ? LIMIT 1",new String[]{target+"%"});boolean ok=c.moveToFirst();c.close();return ok;}
        int monthDays(int y,int m){Calendar a=new GregorianCalendar(y,m,1),b=new GregorianCalendar(y,m,1);b.set(Calendar.DAY_OF_MONTH,b.getActualMaximum(Calendar.DAY_OF_MONTH));String lo=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(a.getTime()),hi=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(b.getTime());Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(DISTINCT substr(date,1,10)) FROM logs WHERE substr(date,1,10) BETWEEN ? AND ?",new String[]{lo,hi});c.moveToFirst();int n=c.getInt(0);c.close();return n;}
        int streak(){int n=0;Calendar c=Calendar.getInstance();String today=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(c.getTime());Cursor first=getReadableDatabase().rawQuery("SELECT 1 FROM logs WHERE date LIKE ? LIMIT 1",new String[]{today+"%"});boolean hasToday=first.moveToFirst();first.close();if(!hasToday)c.add(Calendar.DAY_OF_YEAR,-1);while(true){String d=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(c.getTime());Cursor x=getReadableDatabase().rawQuery("SELECT 1 FROM logs WHERE date LIKE ? LIMIT 1",new String[]{d+"%"});boolean ok=x.moveToFirst();x.close();if(!ok)break;n++;c.add(Calendar.DAY_OF_YEAR,-1);if(n>366)break;}return n;}
        float[] weeklyVolumeChart(){ArrayList<Float>a=new ArrayList<>();for(int i=5;i>=0;i--)a.add((float)rangeVolume(i*7,i*7+6));float[]v=new float[a.size()];for(int i=0;i<v.length;i++)v[i]=a.get(i);return v;}
        static String formatStatic(double v){if(v>=1000)return String.format(Locale.US,"%.1f t",v/1000.0);return String.format(Locale.US,"%.0f kg",v);}
    }
}
