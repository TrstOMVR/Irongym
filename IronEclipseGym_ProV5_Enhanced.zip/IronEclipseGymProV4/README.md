# IRON ECLIPSE Pro V5 UI Refresh

This build keeps the app offline and focuses on a cleaner, more premium gym-tracker UI.

## Changes
- Reworked dashboard with a stronger hero section and compact stats.
- Animated cards and touch feedback.
- Cleaner workout tabs and session summary.
- Larger, cleaner exercise cards with verified exercise labels.
- Replaced the old badly-cropped exercise thumbnails with correctly aligned crops from the supplied 3-day program reference image.
- Improved validation for kg / reps / RIR inputs.
- Fixed estimated-1RM empty-database handling.
- Fixed dialog sizing by applying window size after `show()`.
- Added a full-screen program-reference viewer.
- Kept local SQLite storage and offline behavior; no internet permission added.

## Image verification
Exercise identities were cross-checked against public exercise-library references. Wikimedia Commons has a weight-training gallery covering examples such as leg extension, leg curl, pulldown, fly, lateral raise, pushdown and biceps curl, and individual exercise files are available under Creative Commons licenses. The packaged thumbnails use the user's supplied program reference so the app remains offline and avoids mixing an incorrect web image with a specific exercise.

References:
- Wikimedia Commons — Weight training: https://commons.wikimedia.org/wiki/Weight_training
- Wikimedia Commons — T-bar row: https://commons.wikimedia.org/wiki/File:T-bar-row-1.png
- Wikimedia Commons — lateral raise: https://commons.wikimedia.org/wiki/File:Dumbbell-lateral-raises-1.png
- Wikimedia Commons — lat pulldown: https://commons.wikimedia.org/wiki/File:Close-grip-front-lat-pull-down-1.png
- Wikimedia Commons — triceps pushdown: https://commons.wikimedia.org/wiki/File:Triceps-pushdown-with-v-bar-1.gif

No network permission was added, so exercise images are bundled and the app does not depend on a live connection.
