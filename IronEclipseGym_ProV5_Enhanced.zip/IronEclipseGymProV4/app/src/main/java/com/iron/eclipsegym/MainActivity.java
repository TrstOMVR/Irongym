package com.iron.eclipsegym;

import android.app.*;
import android.os.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.content.*;
import android.database.*;
import android.database.sqlite.*;
import android.view.*;
import android.view.animation.*;
import android.widget.*;
import java.text.*;
import java.util.*;
import android.animation.ObjectAnimator;
import android.animation.AnimatorSet;
import android.media.MediaPlayer;

public class MainActivity extends Activity {
    final int BG=Color.rgb(6,7,8), PANEL=Color.rgb(16,17,19), PANEL2=Color.rgb(23,25,28);
    final int LINE=Color.rgb(42,45,49), TXT=Color.rgb(245,246,248), MUTED=Color.rgb(151,156,164);
    final int RED=Color.rgb(220,42,42), RED2=Color.rgb(110,16,20), GREEN=Color.rgb(177,210,188);

    DB db; LinearLayout root, body; Handler handler=new Handler(); long timerEnd; MediaPlayer introPlayer;
    final String[] days={"SUNDAY","TUESDAY","THURSDAY"};
    final String[] dayArabic={"الأحد","الثلاثاء","الخميس"};
    final String[][] ex={
        {"Upper Chest Press","T-Bar Row","Lat Pulldown","Biceps Curl","Triceps Extension (Pushdown)","Lateral Raise","Leg Extension (Quads)","Tibialis Raise"},
        {"Chest Press","Lat Pulldown","Single-Arm Lat Extension","Biceps Curl","Triceps Extension","Lateral Raise","Leg Curl (Hamstrings)"},
        {"Fly","Upper Chest Press","Lat Pulldown","T-Bar Row","Biceps Curl","Triceps Extension","Lateral Raise","Deadlift","Lateral Raise (2)"}
    };
    final int[][] sets={{2,2,1,2,2,2,2,2},{2,2,1,2,2,2,2},{2,2,1,2,1,1,2,1,2}};
    final String[][] reps={{"6–8","6–8","6–8","6–8","6–8","6–8","6–8","8–12"},{"6–8","6–8","6–8","6–8","6–8","6–8","6–8"},{"6–8","6–8","6–8","6–8","6–8","6–8","6–8","6","6–8"}};

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        db=new DB(this); showIntro();
    }

    TextView t(String s,float z,int c){
        TextView v=new TextView(this); v.setText(s); v.setTextSize(z); v.setTextColor(c);
        v.setGravity(Gravity.CENTER_VERTICAL); v.setPadding(14,7,14,7); return v;
    }
    TextView bold(String s,float z){ TextView v=t(s,z,TXT); v.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return v; }

    GradientDrawable bg(int color,int stroke){
        GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(22);
        if(stroke>0) g.setStroke(1,LINE); return g;
    }
    GradientDrawable redBg(){
        GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,
            new int[]{RED,Color.rgb(150,22,28)}); g.setCornerRadius(22); return g;
    }
    Button button(String s){
        Button b=new Button(this); b.setText(s); b.setTextColor(TXT); b.setTextSize(11);
        b.setAllCaps(false); b.setMinHeight(0); b.setMinWidth(0); b.setPadding(10,0,10,0);
        b.setBackground(bg(PANEL2,1)); b.setStateListAnimator(null); return b;
    }
    EditText field(String h){
        EditText e=new EditText(this); e.setHint(h); e.setHintTextColor(MUTED); e.setTextColor(TXT);
        e.setTextSize(12); e.setSingleLine(); e.setInputType(2|8192); e.setPadding(10,0,10,0);
        e.setBackground(bg(PANEL2,1)); return e;
    }

    void animateIn(View v,int delay){
        v.setAlpha(0f); v.setTranslationY(18f);
        v.animate().alpha(1f).translationY(0f).setDuration(360).setStartDelay(delay)
            .setInterpolator(new DecelerateInterpolator()).start();
    }
    void pressAnim(View v){
        v.setOnTouchListener((view,event)->{
            if(event.getAction()==MotionEvent.ACTION_DOWN)
                view.animate().scaleX(.985f).scaleY(.985f).setDuration(70).start();
            else if(event.getAction()==MotionEvent.ACTION_UP || event.getAction()==MotionEvent.ACTION_CANCEL)
                view.animate().scaleX(1f).scaleY(1f).setDuration(90).start();
            return false;
        });
    }

    void shell(String title){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG);
        LinearLayout head=new LinearLayout(this); head.setOrientation(LinearLayout.VERTICAL); head.setPadding(16,16,16,7);

        LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
        TextView mark=bold("IRON",20); mark.setTextColor(RED); row.addView(mark);
        TextView mark2=bold(" ECLIPSE",20); row.addView(mark2);
        Space sp=new Space(this); row.addView(sp,new LinearLayout.LayoutParams(0,1,1));
        TextView dot=t("●",13,RED); row.addView(dot,new LinearLayout.LayoutParams(30,30));
        head.addView(row);
        TextView sub=t(title+"  /  FORGED IN SILENCE",11,MUTED); sub.setPadding(2,1,2,2); head.addView(sub);
        root.addView(head);

        ScrollView sv=new ScrollView(this); sv.setClipToPadding(false);
        body=new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL); body.setPadding(14,8,14,110);
        sv.addView(body); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1)); nav();
        setContentView(root);
    }

    void nav(){
        LinearLayout n=new LinearLayout(this); n.setPadding(8,7,8,7); n.setBackgroundColor(PANEL);
        String[] a={"HOME","WORKOUT","PROGRESS","PR"};
        for(String s:a){
            Button b=button(s); b.setTextSize(10); n.addView(b,new LinearLayout.LayoutParams(0,55,1));
            if(s.equals("HOME")) b.setOnClickListener(v->home());
            if(s.equals("WORKOUT")) b.setOnClickListener(v->workout(nextDay()));
            if(s.equals("PROGRESS")) b.setOnClickListener(v->progress());
            if(s.equals("PR")) b.setOnClickListener(v->pr());
        }
        root.addView(n,new LinearLayout.LayoutParams(-1,70));
    }
    void gap(){ Space x=new Space(this); body.addView(x,new LinearLayout.LayoutParams(1,9)); }

    LinearLayout baseCard(){
        LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(13,12,13,12);
        c.setBackground(bg(PANEL,1)); c.setElevation(3f); pressAnim(c); return c;
    }
    void card(String title,String sub,View.OnClickListener l){
        LinearLayout c=baseCard(); c.addView(bold(title,16));
        if(sub!=null){ TextView x=t(sub,12,MUTED); c.addView(x); }
        if(l!=null) c.setOnClickListener(l); body.addView(c); animateIn(c,60+body.getChildCount()*20); gap();
    }
    void addStat(LinearLayout stats,String label,String value){
        LinearLayout c=baseCard(); c.setGravity(Gravity.CENTER); c.setPadding(6,10,6,10);
        c.addView(bold(value,20)); TextView lab=t(label,9,MUTED); lab.setGravity(Gravity.CENTER); c.addView(lab);
        stats.addView(c,new LinearLayout.LayoutParams(0,82,1)); animateIn(c,100+stats.getChildCount()*40);
    }
    void hero(String title,String sub){
        LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(17,18,17,18);
        c.setBackground(redBg()); c.setElevation(6f);
        TextView a=bold(title,25); a.setTextColor(Color.WHITE); c.addView(a);
        TextView b=t(sub,11,Color.WHITE); b.setAlpha(.88f); c.addView(b);
        body.addView(c); animateIn(c,20); gap();
    }

    void home(){
        shell("DASHBOARD");
        hero("3 DAY FULL BODY","LOW VOLUME  •  HIGH INTENSITY     6–8 REPS  •  TRAIN TO FAILURE");
        LinearLayout stats=new LinearLayout(this); stats.setWeightSum(3);
        addStat(stats,"LOGGED SETS",String.valueOf(db.count()));
        addStat(stats,"EXERCISES",String.valueOf(uniqueExercises()));
        addStat(stats,"PRs",String.valueOf(db.prCount()));
        body.addView(stats); gap();

        int d=nextDay();
        card("NEXT SESSION",dayArabic[d]+"  •  FULL BODY "+(char)('A'+d),v->workout(d));
        card("LAST SET",db.last(),v->progress());
        card("REST TIMER","3:00 default  •  tap to start",v->timer(180));
        card("SESSION CHECKLIST","Warm up, set your setup, train hard, log every set",v->checklist());
    }

    int uniqueExercises(){HashSet<String>s=new HashSet<>(); for(String[] a:ex)for(String x:a)s.add(x.replace(" (2)","")); return s.size();}
    int nextDay(){
        Calendar c=Calendar.getInstance(); int d=c.get(Calendar.DAY_OF_WEEK);
        if(d==Calendar.SUNDAY)return 0;
        if(d==Calendar.MONDAY)return 1;
        if(d==Calendar.TUESDAY)return 1;
        if(d==Calendar.WEDNESDAY)return 2;
        if(d==Calendar.THURSDAY)return 2;
        return 0; // Friday/Saturday → next session is Sunday
    }

    void workout(int di){
        shell(dayArabic[di]+"  •  FULL BODY "+(char)('A'+di));
        LinearLayout tabs=new LinearLayout(this); tabs.setWeightSum(3);
        for(int i=0;i<3;i++){ final int q=i; Button b=button(dayArabic[i]); if(i==di)b.setBackground(redBg());
            tabs.addView(b,new LinearLayout.LayoutParams(0,52,1)); b.setOnClickListener(v->workout(q)); }
        body.addView(tabs); gap();
        hero("SESSION READY",""+ex[di].length+" EXERCISES   •   "+setsCount(di)+" WORKING SETS   •   REST 3:00");
        for(int i=0;i<ex[di].length;i++) exercise(di,i);
    }
    int setsCount(int di){int n=0;for(int x:sets[di])n+=x;return n;}

    void exercise(int di,int ei){
        String name=ex[di][ei].replace(" (2)","");
        LinearLayout c=baseCard(); c.setPadding(10,10,10,10);
        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        ImageView im=exerciseImage(name); top.addView(im,new LinearLayout.LayoutParams(96,78));
        LinearLayout info=new LinearLayout(this); info.setOrientation(LinearLayout.VERTICAL); info.setPadding(10,0,6,0);
        info.addView(bold(name,16)); info.addView(t(muscleFor(name).toUpperCase(Locale.US),9,MUTED));
        info.addView(t(sets[di][ei]+" × "+reps[di][ei]+"   •   FAILURE",11,RED));
        top.addView(info,new LinearLayout.LayoutParams(0,-2,1));
        Button details=button("DETAILS"); top.addView(details,new LinearLayout.LayoutParams(76,48));
        c.addView(top);

        String last=db.lastFor(name);
        if(!last.equals("—")){TextView lp=t("LAST  "+last,10,MUTED); lp.setPadding(106,2,5,5); c.addView(lp);}

        for(int si=1;si<=sets[di][ei];si++){
            LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
            TextView sn=t("SET "+si,10,MUTED); sn.setGravity(Gravity.CENTER); row.addView(sn,new LinearLayout.LayoutParams(52,48));
            EditText w=field("kg"),r=field("reps");
            row.addView(w,new LinearLayout.LayoutParams(0,48,1)); row.addView(r,new LinearLayout.LayoutParams(0,48,1));
            TextView fail=t("FAILURE",10,RED); fail.setGravity(Gravity.CENTER); row.addView(fail,new LinearLayout.LayoutParams(0,48,1));
            Button save=button("SAVE"); row.addView(save,new LinearLayout.LayoutParams(60,48));
            final String logName=name; final Button saveBtn=save;
            save.setOnClickListener(v->{try{
                double kg=Double.parseDouble(w.getText().toString()); int rr=Integer.parseInt(r.getText().toString());
                int ri=0;
                if(kg<=0||rr<=0||rr>100) throw new Exception();
                db.log(logName,kg,rr,ri); saveBtn.setText("SAVED"); saveBtn.setTextColor(GREEN);
                Toast.makeText(this,"Set saved",Toast.LENGTH_SHORT).show();
            }catch(Exception z){Toast.makeText(this,"Enter a valid weight and reps",Toast.LENGTH_SHORT).show();}});
            c.addView(row); gapSmall(c);
        }
        Button rest=button("START 3:00 REST"); rest.setBackground(redBg()); rest.setOnClickListener(v->timer(180)); c.addView(rest);
        details.setOnClickListener(v->exerciseDetails(name,di,ei)); c.setOnClickListener(v->{}); body.addView(c);
        animateIn(c,70+body.getChildCount()*18); gap();
    }
    void gapSmall(LinearLayout l){Space s=new Space(this);l.addView(s,new LinearLayout.LayoutParams(1,4));}

    ImageView exerciseImage(String name){
        ImageView im=new ImageView(this); int id=imgId(name); if(id!=0)im.setImageResource(id);
        im.setScaleType(ImageView.ScaleType.CENTER_CROP); im.setBackground(bg(PANEL2,1)); im.setClipToOutline(true);
        return im;
    }
    int imgId(String n){
        if(n.equals("Upper Chest Press"))return R.drawable.upper_chest_press;
        if(n.equals("T-Bar Row"))return R.drawable.tbar_row;
        if(n.equals("Lat Pulldown"))return R.drawable.lat_pulldown;
        if(n.equals("Biceps Curl"))return R.drawable.biceps_curl;
        if(n.contains("Triceps Extension"))return R.drawable.triceps_extension;
        if(n.equals("Lateral Raise"))return R.drawable.lateral_raise;
        if(n.equals("Leg Extension (Quads)"))return R.drawable.leg_extension;
        if(n.equals("Tibialis Raise"))return R.drawable.tibialis_raise;
        if(n.equals("Chest Press"))return R.drawable.chest_press;
        if(n.equals("Single-Arm Lat Extension"))return R.drawable.single_arm_lat_extension;
        if(n.equals("Leg Curl (Hamstrings)"))return R.drawable.leg_curl;
        if(n.equals("Fly"))return R.drawable.fly;
        if(n.equals("Deadlift"))return R.drawable.deadlift;
        return 0;
    }
    String muscleFor(String n){
        if(n.contains("Chest")||n.equals("Fly"))return "Chest";
        if(n.contains("Row")||n.contains("Pulldown")||n.contains("Lat"))return "Back / Lats";
        if(n.contains("Biceps"))return "Biceps";
        if(n.contains("Triceps"))return "Triceps";
        if(n.contains("Lateral Raise"))return "Lateral Delts";
        if(n.contains("Leg Extension"))return "Quads";
        if(n.contains("Leg Curl"))return "Hamstrings";
        if(n.contains("Tibialis"))return "Tibialis";
        if(n.equals("Deadlift"))return "Hamstrings / Glutes / Back";
        return "—";
    }
    String guideFor(String n){
        if(n.contains("Chest Press"))return "Keep shoulder blades stable, control the descent, and press smoothly without bouncing.";
        if(n.equals("Fly"))return "Use a controlled stretch and bring the handles together without turning the movement into a press.";
        if(n.equals("T-Bar Row"))return "Brace your torso, pull toward the lower chest or upper abdomen, then control the lowering phase.";
        if(n.equals("Lat Pulldown"))return "Pull toward the upper chest with the elbows driving down; avoid excessive swinging.";
        if(n.contains("Lat Extension"))return "Keep the upper arm stable and move through a controlled range.";
        if(n.contains("Biceps"))return "Keep the upper arm relatively still, curl through the elbow, and control the lowering phase.";
        if(n.contains("Triceps"))return "Keep the elbows stable and extend under control.";
        if(n.equals("Lateral Raise"))return "Raise with controlled motion and avoid using momentum.";
        if(n.contains("Leg Extension"))return "Align the knee with the machine pivot and extend smoothly without bouncing.";
        if(n.contains("Leg Curl"))return "Keep the hips stable and curl the pad through a controlled range.";
        if(n.contains("Tibialis"))return "Lift the forefoot through a controlled range while keeping the heel planted.";
        if(n.equals("Deadlift"))return "Brace first, keep the load close, hinge at the hips, and stop if technique breaks down.";
        return "Use controlled reps and stable technique. Stop the set when safe technique can no longer be maintained.";
    }

    void exerciseDetails(String name,int di,int ei){
        final Dialog d=new Dialog(this);
        LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(18,18,18,18); l.setBackground(bg(PANEL,1));
        LinearLayout head=new LinearLayout(this); head.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(bold(name,21),new LinearLayout.LayoutParams(0,-2,1));
        Button x=button("×"); head.addView(x,new LinearLayout.LayoutParams(48,48)); l.addView(head);
        ImageView im=exerciseImage(name); l.addView(im,new LinearLayout.LayoutParams(-1,235));
        l.addView(t("TARGET  •  "+muscleFor(name),12,RED));
        l.addView(t("PROGRAM  •  "+sets[di][ei]+" SETS × "+reps[di][ei]+"  •  FAILURE",12,TXT));
        l.addView(t("FORM GUIDE\n"+guideFor(name),12,MUTED));
        l.addView(t("LAST PERFORMANCE\n"+db.lastFor(name),12,MUTED));
        Button history=button("VIEW EXERCISE PROGRESS"); l.addView(history);
        Button close=button("CLOSE"); l.addView(close);
        x.setOnClickListener(v->d.dismiss()); close.setOnClickListener(v->d.dismiss());
        history.setOnClickListener(v->{d.dismiss();exerciseProgress(name);});
        d.setContentView(l); d.show();
        Window w=d.getWindow(); if(w!=null){w.setBackgroundDrawable(bg(PANEL,1)); w.setLayout(-1,-2);}
        animateIn(l,0);
    }

    void exerciseProgress(String name){
        shell(name+"  •  PROGRESS");
        card("CURRENT PR",db.best(name),null);
        card("RECENT SETS",db.exerciseHistory(name),null);
        body.addView(bold("ESTIMATED 1RM TREND",17)); gap();
        body.addView(new ChartView(this,db.exerciseChart(name)),new LinearLayout.LayoutParams(-1,260));
    }

    void timer(int sec){
        final Dialog d=new Dialog(this); LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(25,25,25,25); l.setBackground(bg(PANEL,1));
        TextView title=bold("REST TIMER",19); title.setGravity(Gravity.CENTER); l.addView(title);
        TextView clock=bold(String.format(Locale.US,"%d:%02d",sec/60,sec%60),52); clock.setGravity(Gravity.CENTER); l.addView(clock,new LinearLayout.LayoutParams(-1,120));
        Button stop=button("STOP"); stop.setBackground(redBg()); l.addView(stop); d.setContentView(l);
        d.show(); Window w=d.getWindow(); if(w!=null){w.setBackgroundDrawable(bg(PANEL,1));w.setLayout(-1,-2);}
        timerEnd=System.currentTimeMillis()+sec*1000L;
        Runnable rr=new Runnable(){public void run(){long left=Math.max(0,timerEnd-System.currentTimeMillis());
            clock.setText(String.format(Locale.US,"%d:%02d",left/60000,(left/1000)%60));
            if(left>0)handler.postDelayed(this,200); else {clock.setText("DONE");clock.setTextColor(RED);}
        }};
        stop.setOnClickListener(v->{handler.removeCallbacks(rr);d.dismiss();}); d.setOnDismissListener(x->handler.removeCallbacks(rr)); handler.post(rr);
    }

    void progress(){
        shell("PROGRESS");
        hero("KEEP MOVING","Every saved set becomes part of your history.");
        card("TRAINING VOLUME","Logged sets: "+db.count(),null);
        if(db.count()==0){body.addView(t("No sets logged yet. Start your first session.",14,MUTED));return;}
        card("RECENT HISTORY",db.recent(),null);
        body.addView(bold("OVERALL ESTIMATED 1RM TREND",17)); gap();
        body.addView(new ChartView(this,db.chart()),new LinearLayout.LayoutParams(-1,260));
    }

    void pr(){
        shell("PR LAB"); hero("ESTIMATED 1RM","Epley formula • use it as an estimate, not a test of maximum strength.");
        LinearLayout fields=new LinearLayout(this); fields.setWeightSum(2);
        EditText w=field("weight kg"),r=field("reps"); fields.addView(w,new LinearLayout.LayoutParams(0,54,1));fields.addView(r,new LinearLayout.LayoutParams(0,54,1));body.addView(fields);gap();
        Button calc=button("CALCULATE 1RM");calc.setBackground(redBg());body.addView(calc);
        TextView out=bold("—",25);out.setGravity(Gravity.CENTER);body.addView(out);calc.setOnClickListener(v->{try{
            double x=Double.parseDouble(w.getText().toString());int y=Integer.parseInt(r.getText().toString());
            if(x<=0||y<1||y>30)throw new Exception();out.setText(String.format(Locale.US,"%.1f kg",x*(1+y/30.0)));
        }catch(Exception e){out.setText("Invalid input");}});gap();
        body.addView(bold("PERSONAL RECORDS",18));
        Cursor c=db.raw("SELECT exercise, MAX(weight*(1+reps/30.0)) m FROM logs GROUP BY exercise ORDER BY m DESC");
        while(c.moveToNext())card(c.getString(0),String.format(Locale.US,"Estimated 1RM  •  %.1f kg",c.getDouble(1)),null); c.close();
    }

    void checklist(){
        final Dialog d=new Dialog(this);
        LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(20,20,20,20); l.setBackground(bg(PANEL,1));
        l.addView(bold("SESSION CHECKLIST",21));
        l.addView(t("01  •  WARM UP",13,RED));
        l.addView(t("Do a few easy ramp-up sets before the first heavy working set.",12,MUTED));
        l.addView(t("02  •  SETUP",13,RED));
        l.addView(t("Adjust the machine or rack, brace properly, and keep the same setup between sets.",12,MUTED));
        l.addView(t("03  •  FAILURE",13,RED));
        l.addView(t("Train the programmed working sets hard, but end the set if safe technique breaks down.",12,MUTED));
        l.addView(t("04  •  REST",13,RED));
        l.addView(t("Take the full 3:00 timer between working sets unless your plan says otherwise.",12,MUTED));
        l.addView(t("05  •  LOG",13,RED));
        l.addView(t("Save the weight and reps immediately so your progress history stays accurate.",12,MUTED));
        Button close=button("CLOSE"); l.addView(close); close.setOnClickListener(v->d.dismiss());
        d.setContentView(l); d.show(); Window w=d.getWindow(); if(w!=null){w.setBackgroundDrawable(bg(PANEL,1));w.setLayout(-1,-2);} animateIn(l,0);
    }

    void showIntro(){
        final LinearLayout splash=new LinearLayout(this); splash.setOrientation(LinearLayout.VERTICAL); splash.setGravity(Gravity.CENTER); splash.setPadding(28,28,28,28); splash.setBackgroundColor(BG);
        final EclipseView eclipse=new EclipseView(this); splash.addView(eclipse,new LinearLayout.LayoutParams(-1,300));
        TextView title=bold("IRON ECLIPSE",30); title.setGravity(Gravity.CENTER); title.setTextColor(Color.WHITE); splash.addView(title);
        TextView sub=t("STRUGGLE  •  DISCIPLINE  •  PROGRESS",10,MUTED); sub.setGravity(Gravity.CENTER); splash.addView(sub);
        setContentView(splash);
        eclipse.setScaleX(.82f); eclipse.setScaleY(.82f); eclipse.setAlpha(.2f); title.setAlpha(0f); sub.setAlpha(0f);
        eclipse.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(850).setInterpolator(new DecelerateInterpolator()).start();
        title.animate().alpha(1f).setDuration(650).setStartDelay(450).start(); sub.animate().alpha(1f).setDuration(600).setStartDelay(700).start();
        try{ introPlayer=MediaPlayer.create(this,R.raw.intro_tone); if(introPlayer!=null){introPlayer.setOnCompletionListener(mp->{mp.release();introPlayer=null;}); introPlayer.start();}}catch(Exception ignored){}
        handler.postDelayed(()->{ if(introPlayer!=null){try{introPlayer.release();}catch(Exception ignored){} introPlayer=null;} home(); },1700);
    }

    @Override protected void onDestroy(){
        handler.removeCallbacksAndMessages(null);
        if(introPlayer!=null){try{introPlayer.release();}catch(Exception ignored){}}
        super.onDestroy();
    }

    static class EclipseView extends View{
        Paint p=new Paint(1); EclipseView(Context c){super(c);p.setAntiAlias(true);}
        protected void onDraw(Canvas c){
            super.onDraw(c); float cx=getWidth()/2f, cy=getHeight()/2f;
            p.setColor(Color.rgb(45,8,10)); c.drawCircle(cx,cy,105,p);
            p.setColor(Color.rgb(220,42,42)); c.drawCircle(cx,cy,76,p);
            p.setColor(Color.rgb(6,7,8)); c.drawCircle(cx,cy,48,p);
            p.setColor(Color.rgb(15,15,16));
            Path path=new Path(); path.moveTo(cx-95,cy+100); path.lineTo(cx-60,cy+20); path.lineTo(cx-28,cy+5); path.lineTo(cx-14,cy-35); path.lineTo(cx+5,cy-55); path.lineTo(cx+25,cy-30); path.lineTo(cx+40,cy+10); path.lineTo(cx+72,cy+45); path.lineTo(cx+105,cy+100); path.close(); c.drawPath(path,p);
            p.setColor(Color.rgb(220,42,42)); p.setStrokeWidth(3); c.drawLine(cx+25,cy-100,cx+105,cy-20,p);
        }
    }

    static class ChartView extends View{
        Paint p=new Paint(1);float[] vals; ChartView(Context c,float[]v){super(c);vals=v;p.setStrokeWidth(5);}
        protected void onDraw(Canvas c){super.onDraw(c);c.drawColor(Color.rgb(16,17,19)); if(vals.length<2){p.setColor(Color.GRAY);p.setTextSize(14);c.drawText("Log more sets to see your trend.",16,30,p);return;}
            float max=1;for(float v:vals)max=Math.max(max,v);float dx=getWidth()*1f/(vals.length-1);
            p.setColor(Color.rgb(220,42,42));p.setStrokeWidth(5);
            for(int i=1;i<vals.length;i++){float x1=(i-1)*dx,x2=i*dx,y1=getHeight()-30-(vals[i-1]/max)*(getHeight()-60),y2=getHeight()-30-(vals[i]/max)*(getHeight()-60);c.drawLine(x1,y1,x2,y2,p);}
            p.setTextSize(22);p.setColor(Color.LTGRAY);c.drawText("1RM",16,28,p);
        }
    }

    static class DB extends SQLiteOpenHelper{
        DB(Context c){super(c,"iron_eclipse_pro.db",null,5);}
        public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE logs(id INTEGER PRIMARY KEY AUTOINCREMENT,exercise TEXT,weight REAL,reps INTEGER,rir INTEGER,date TEXT)");}
        public void onUpgrade(SQLiteDatabase d,int a,int b){}
        void log(String e,double w,int r,int rir){getWritableDatabase().execSQL("INSERT INTO logs(exercise,weight,reps,rir,date) VALUES(?,?,?,?,?)",
            new Object[]{e,w,r,rir,new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(new Date())});}
        Cursor raw(String q){return getReadableDatabase().rawQuery(q,null);}
        int count(){Cursor c=raw("SELECT COUNT(*) FROM logs");c.moveToFirst();int n=c.getInt(0);c.close();return n;}
        int prCount(){Cursor c=raw("SELECT COUNT(DISTINCT exercise) FROM logs");c.moveToFirst();int n=c.getInt(0);c.close();return n;}
        String last(){Cursor c=raw("SELECT exercise,weight,reps FROM logs ORDER BY id DESC LIMIT 1");if(c.moveToFirst()){String s=c.getString(0)+"  •  "+c.getDouble(1)+" kg × "+c.getInt(2);c.close();return s;}c.close();return "No sets logged yet.";}
        String lastFor(String e){Cursor c=getReadableDatabase().rawQuery("SELECT weight,reps,rir FROM logs WHERE exercise=? ORDER BY id DESC LIMIT 1",new String[]{e});if(c.moveToFirst()){String s=c.getDouble(0)+" kg × "+c.getInt(1)+" • FAILURE";c.close();return s;}c.close();return "—";}
        String recent(){Cursor c=raw("SELECT exercise,weight,reps,rir,date FROM logs ORDER BY id DESC LIMIT 12");StringBuilder s=new StringBuilder();while(c.moveToNext())s.append(c.getString(0)).append("  |  ").append(c.getDouble(1)).append(" kg × ").append(c.getInt(2)).append("  | FAILURE\n");c.close();return s.toString();}
        String best(String e){Cursor c=getReadableDatabase().rawQuery("SELECT MAX(weight*(1+reps/30.0)) FROM logs WHERE exercise=?",new String[]{e});c.moveToFirst();double x=c.isNull(0)?0:c.getDouble(0);c.close();return x>0?String.format(Locale.US,"Best estimated 1RM  •  %.1f kg",x):"No PR yet.";}
        String exerciseHistory(String e){Cursor c=getReadableDatabase().rawQuery("SELECT weight,reps,rir,date FROM logs WHERE exercise=? ORDER BY id DESC LIMIT 15",new String[]{e});StringBuilder s=new StringBuilder();while(c.moveToNext())s.append(c.getDouble(0)).append(" kg × ").append(c.getInt(1)).append("  • FAILURE  • ").append(c.getString(3)).append("\n");c.close();return s.length()==0?"No logged sets yet.":s.toString();}
        float[] exerciseChart(String e){Cursor c=getReadableDatabase().rawQuery("SELECT weight*(1+reps/30.0) FROM logs WHERE exercise=? ORDER BY id ASC",new String[]{e});ArrayList<Float>a=new ArrayList<>();while(c.moveToNext())a.add((float)c.getDouble(0));c.close();float[]v=new float[a.size()];for(int i=0;i<v.length;i++)v[i]=a.get(i);return v;}
        float[] chart(){Cursor c=raw("SELECT weight*(1+reps/30.0) FROM logs ORDER BY id ASC LIMIT 30");ArrayList<Float>a=new ArrayList<>();while(c.moveToNext())a.add((float)c.getDouble(0));c.close();float[]v=new float[a.size()];for(int i=0;i<v.length;i++)v[i]=a.get(i);return v;}
    }
}
