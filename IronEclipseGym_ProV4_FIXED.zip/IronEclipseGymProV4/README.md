# IRON ECLIPSE Pro V4

Offline Android gym tracker based on the user's supplied 3-day Full Body program.

## V4 features
- Sunday / Tuesday / Thursday Full Body A/B/C program.
- Exact programmed sets/reps from the supplied image.
- Individual set logging: kg, reps, RIR.
- Last performance shown beside each exercise.
- Rest timer.
- Estimated 1RM / PR calculator and per-exercise PRs.
- Per-exercise detail view with a reference exercise image, target muscle, form guide, programmed sets/reps, last performance, recent history and 1RM trend.
- Overall progress history and 1RM trend.
- Supplied program image embedded as an in-app reference.
- SQLite local database. No internet permission.

The exercise reference images are cropped from the user's supplied program image.
