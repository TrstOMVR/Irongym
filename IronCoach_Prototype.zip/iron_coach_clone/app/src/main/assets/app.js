const DAYS = {
  A:{title:'FULL BODY A',sub:'8 exercises • low volume / high intensity',ex:[
    ['Upper Chest Press','Chest','2 × 6–8','assets/ex_1.jpg'],['T-Bar Row','Back','2 × 6–8','assets/ex_2.jpg'],['Lat Pulldown','Lats','1 × 6–8','assets/ex_3.jpg'],['Biceps Curl','Biceps','2 × 6–8','assets/ex_4.jpg'],['Triceps Extension (Pushdown)','Triceps','2 × 6–8','assets/ex_5.jpg'],['Lateral Raise','Lateral delts','2 × 6–8','assets/ex_6.jpg'],['Leg Extension (Quads)','Quads','2 × 6–8','assets/ex_7.jpg'],['Tibialis Raise','Tibialis','2 × 8–12','assets/ex_8.jpg']
  ]},
  B:{title:'FULL BODY B',sub:'7 exercises • low volume / high intensity',ex:[
    ['Chest Press','Chest','2 × 6–8','assets/ex_1.jpg'],['Lat Pulldown','Lats','2 × 6–8','assets/ex_3.jpg'],['Single-Arm Lat Extension','Back','1 × 6–8','assets/ex_2.jpg'],['Biceps Curl','Biceps','2 × 6–8','assets/ex_4.jpg'],['Triceps Extension','Triceps','2 × 6–8','assets/ex_5.jpg'],['Lateral Raise','Lateral delts','2 × 6–8','assets/ex_6.jpg'],['Leg Curl (Hamstrings)','Hamstrings','2 × 6–8','assets/ex_7.jpg']
  ]},
  C:{title:'FULL BODY C',sub:'9 exercises • low volume / high intensity',ex:[
    ['Fly','Chest','2 × 6–8','assets/ex_1.jpg'],['Upper Chest Press','Chest','2 × 6–8','assets/ex_1.jpg'],['Lat Pulldown','Lats','1 × 6–8','assets/ex_3.jpg'],['T-Bar Row','Back','2 × 6–8','assets/ex_2.jpg'],['Biceps Curl','Biceps','1 × 6–8','assets/ex_4.jpg'],['Triceps Extension','Triceps','1 × 6–8','assets/ex_5.jpg'],['Lateral Raise','Lateral delts','2 × 6–8','assets/ex_6.jpg'],['Deadlift','Posterior chain','1 × 6 • 1–2 RIR','assets/ex_2.jpg'],['Lateral Raise','Lateral delts','2 × 6–8','assets/ex_6.jpg']
  ]}
};
let screen='workout', day='A';
const host=document.getElementById('screenHost');
function esc(s){return s.replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));}
function renderWorkout(){
  const d=DAYS[day];
  host.innerHTML=`<section class="screen">
    <div class="hero workout">
      <div class="hero-content">
        <div class="kicker">TRAINING PROTOCOL</div>
        <h1>3 DAY<br>FULL BODY</h1>
        <div class="subtitle">LOW VOLUME • HIGH INTENSITY</div>
        <div class="hero-metrics"><div class="metric"><strong>6–8</strong> REPS</div><div class="metric"><strong>1–2</strong> RIR</div><div class="metric"><strong>3</strong> DAYS / WEEK</div></div>
        <button class="cta" id="startBtn">▶ START WORKOUT</button>
        <button class="secondary" id="historyBtn">◷ LOG HISTORY</button>
      </div>
    </div>
    <div class="day-strip">${Object.entries(DAYS).map(([k,v])=>`<button class="day ${day===k?'active':''}" data-day="${k}"><b>${v.title}</b><small>${v.ex.length} exercises</small></button>`).join('')}<button class="day" id="restDay"><b>REST DAY</b><small>Rest & Recovery</small></button></div>
    <div class="section-title"><h2>${d.title}</h2><button id="sheetBtn">VIEW PROGRAM SHEET</button></div>
    <div class="exercise-list">${d.ex.map((e,i)=>`<article class="exercise"><img class="thumb" src="${e[3]}"/><div class="ex-main"><b>${esc(e[0])}</b><span>${esc(e[1])}</span></div><div class="ex-meta"><span class="sets">${esc(e[2])}</span><span class="rir">${e[2].includes('RIR')?'':'TARGET RIR 1–2'}</span></div></article>`).join('')}</div>
    <div class="section-title"><h2>WEEKLY VOLUME</h2><button id="sheetBtn2">ORIGINAL PLAN</button></div>
    <div class="note"><strong>Training rule:</strong> use controlled loads that allow the target reps with <strong>1–2 RIR</strong>. Rest roughly 2–3 minutes on compounds and progress the load only when the top of the rep range is reached with clean form.</div>
  </section>`;
  document.querySelectorAll('[data-day]').forEach(b=>b.onclick=()=>{day=b.dataset.day;renderWorkout();});
  document.getElementById('startBtn').onclick=()=>openWorkout();
  document.getElementById('sheetBtn').onclick=()=>openProgram();
  document.getElementById('sheetBtn2').onclick=()=>openProgram();
  document.getElementById('historyBtn').onclick=()=>showToast('History will appear here after your first logged session.');
  document.getElementById('restDay').onclick=()=>showToast('REST DAY • Recovery & readiness');
}
function renderProgress(){
 host.innerHTML=`<section class="screen">
   <div class="hero progress">
     <div class="hero-content">
       <div class="kicker">LEVEL 01 • AWAKENED</div>
       <h1>ATLAS</h1>
       <div class="subtitle">Bearer of the first burden</div>
       <div class="progress-grid">
         <div class="stat"><small>Weight</small><b>—</b><span>log your current kg</span></div>
         <div class="stat"><small>Body Position</small><b>—</b><span>update in your profile</span></div>
         <div class="stat"><small>Skills</small><b>0</b><span>tracked milestones</span></div>
       </div>
     </div>
   </div>
   <div class="ascent">
     <div class="section-title"><h2>THE ASCENT</h2><button onclick="showToast('Milestones unlock from consistent logging.')">HOW IT WORKS</button></div>
     <div class="ascent-row"><div class="rank active"><b>01 · ATLAS</b><small>Awakened</small></div><div class="rank"><b>05 · ARES</b><small>Locked</small></div></div>
     <button class="evidence" onclick="showToast('Evidence of ascent will be built from your logged history.')">EVIDENCE OF ASCENT →</button>
   </div>
   <div class="section-title"><h2>TRACKED FROM YOUR WORKOUTS</h2></div>
   <div class="note">Weight trend, completed sets, PRs and consistency can all be stored locally on this device. No nutrition or forms section is included.</div>
 </section>`;
}
function openProgram(){document.getElementById('programModal').classList.remove('hidden');}
function closeProgram(){document.getElementById('programModal').classList.add('hidden');}
function openWorkout(){
 const d=DAYS[day];
 const wrap=document.createElement('div');wrap.className='workout-modal';wrap.id='workoutModal';
 wrap.innerHTML=`<div class="wm-top"><div><div class="wm-title">${d.title}</div><div class="wm-sub">Log every working set • 1–2 RIR target</div></div><button class="back-btn" id="closeWorkout">‹</button></div><div style="overflow:auto;padding-bottom:90px">${d.ex.map((e,i)=>setCard(e,i)).join('')}</div><div class="timer"><div><div style="font-size:9px;color:#8e8078;letter-spacing:1.4px">REST TIMER</div><b id="timerValue">02:00</b></div><button id="skipTimer">SKIP</button></div>`;
 document.body.appendChild(wrap);
 document.getElementById('closeWorkout').onclick=()=>wrap.remove();
 document.getElementById('skipTimer').onclick=()=>showToast('Timer skipped');
 wrap.querySelectorAll('.done').forEach(btn=>btn.onclick=()=>{btn.classList.toggle('checked');if(btn.classList.contains('checked')){showToast('Set logged');startTimer(120);}});
}
function setCard(e,i){let rows='';const sets=parseInt(e[2]); for(let s=1;s<=Math.min(sets,3);s++) rows+=`<div class="set-row"><div class="set-no">${s}</div><input class="input" inputmode="decimal" placeholder="kg"/><input class="input" inputmode="numeric" placeholder="reps"/><button class="done">✓</button></div>`;return `<div class="set-card"><h3>${i+1}. ${esc(e[0])}<span style="float:right;color:#ff7131;font-size:10px">${esc(e[2])}</span></h3>${rows}</div>`}
let timerId=null; function startTimer(sec){clearInterval(timerId);let el=document.getElementById('timerValue');if(!el)return;let t=sec;const tick=()=>{let m=String(Math.floor(t/60)).padStart(2,'0'),s=String(t%60).padStart(2,'0');el.textContent=`${m}:${s}`;if(t<=0)clearInterval(timerId);t--;};tick();timerId=setInterval(tick,1000);}
function setScreen(next){screen=next;document.querySelectorAll('.tab').forEach(t=>t.classList.toggle('active',t.dataset.screen===screen));screen==='workout'?renderWorkout():renderProgress();}
document.querySelectorAll('.tab').forEach(t=>t.onclick=()=>setScreen(t.dataset.screen));
document.querySelector('.close-btn').onclick=closeProgram;
let sx=0;document.addEventListener('touchstart',e=>sx=e.touches[0].clientX,{passive:true});document.addEventListener('touchend',e=>{const dx=e.changedTouches[0].clientX-sx;if(Math.abs(dx)>70){if(dx<0)setScreen('progress');else setScreen('workout');}});
function showToast(msg){const el=document.getElementById('toast');el.textContent=msg;el.classList.add('show');clearTimeout(window.__toast);window.__toast=setTimeout(()=>el.classList.remove('show'),1800)}
renderWorkout();
